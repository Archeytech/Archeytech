import React from 'react';
import { MessageSquare, Clock, BookOpen, Mail } from 'lucide-react';

const SupportSection: React.FC = () => {
  return (
    <section className="py-16 md:py-24 bg-blue-600 text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            24/7 Expert Support
          </h2>
          <p className="text-xl opacity-90">
            Our customer success team is always available to help you with any questions or issues you may have.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="bg-white bg-opacity-10 rounded-xl p-8 backdrop-blur-sm hover:bg-opacity-15 transition-colors">
            <div className="bg-blue-500 w-16 h-16 rounded-full flex items-center justify-center mb-6">
              <MessageSquare className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-bold mb-3">Live Chat</h3>
            <p className="opacity-90 mb-4">
              Connect with our support team instantly through our live chat service.
            </p>
            <a 
              href="#" 
              className="inline-block bg-white text-blue-600 hover:bg-blue-50 font-medium px-5 py-2 rounded-lg transition-colors"
            >
              Start Chat
            </a>
          </div>
          
          <div className="bg-white bg-opacity-10 rounded-xl p-8 backdrop-blur-sm hover:bg-opacity-15 transition-colors">
            <div className="bg-blue-500 w-16 h-16 rounded-full flex items-center justify-center mb-6">
              <Clock className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-bold mb-3">24/7 Phone Support</h3>
            <p className="opacity-90 mb-4">
              Call us anytime, day or night. Our experts are ready to assist you.
            </p>
            <a 
              href="#" 
              className="inline-block bg-white text-blue-600 hover:bg-blue-50 font-medium px-5 py-2 rounded-lg transition-colors"
            >
              Call Now
            </a>
          </div>
          
          <div className="bg-white bg-opacity-10 rounded-xl p-8 backdrop-blur-sm hover:bg-opacity-15 transition-colors">
            <div className="bg-blue-500 w-16 h-16 rounded-full flex items-center justify-center mb-6">
              <BookOpen className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-bold mb-3">Knowledge Base</h3>
            <p className="opacity-90 mb-4">
              Browse our comprehensive guides and tutorials for self-service support.
            </p>
            <a 
              href="#" 
              className="inline-block bg-white text-blue-600 hover:bg-blue-50 font-medium px-5 py-2 rounded-lg transition-colors"
            >
              Explore Guides
            </a>
          </div>
          
          <div className="bg-white bg-opacity-10 rounded-xl p-8 backdrop-blur-sm hover:bg-opacity-15 transition-colors">
            <div className="bg-blue-500 w-16 h-16 rounded-full flex items-center justify-center mb-6">
              <Mail className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-bold mb-3">Email Support</h3>
            <p className="opacity-90 mb-4">
              Send us an email and we'll get back to you with a detailed response.
            </p>
            <a 
              href="#" 
              className="inline-block bg-white text-blue-600 hover:bg-blue-50 font-medium px-5 py-2 rounded-lg transition-colors"
            >
              Email Us
            </a>
          </div>
        </div>
        
        <div className="mt-16 text-center">
          <div className="bg-white bg-opacity-10 rounded-full inline-block px-6 py-3">
            <span className="opacity-90">Average response time: </span>
            <span className="font-bold">Less than 2 minutes</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SupportSection;