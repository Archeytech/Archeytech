import React from 'react';
import { Shield, Zap, Server, Clock, Headphones, ArrowUpRight } from 'lucide-react';

const FeaturesSection: React.FC = () => {
  const features = [
    {
      icon: <Zap className="h-10 w-10 text-blue-600" />,
      title: 'Lightning-Fast Performance',
      description: 'Our LiteSpeed servers with advanced caching ensure your website loads in the blink of an eye.',
    },
    {
      icon: <Shield className="h-10 w-10 text-blue-600" />,
      title: 'Enhanced Security',
      description: 'Free SSL certificates, DDoS protection, and regular security updates keep your site protected.',
    },
    {
      icon: <Server className="h-10 w-10 text-blue-600" />,
      title: 'SSD Storage',
      description: 'All plans come with SSD storage for faster data retrieval and improved website performance.',
    },
    {
      icon: <Clock className="h-10 w-10 text-blue-600" />,
      title: '99.9% Uptime Guarantee',
      description: 'We guarantee exceptional reliability with our 99.9% uptime commitment.',
    },
    {
      icon: <Headphones className="h-10 w-10 text-blue-600" />,
      title: '24/7 Expert Support',
      description: 'Our customer support team is available around the clock to help you with any issues.',
    },
    {
      icon: <ArrowUpRight className="h-10 w-10 text-blue-600" />,
      title: 'One-Click Installs',
      description: 'Install WordPress and other popular applications with just one click.',
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Features Designed for Your Success
          </h2>
          <p className="text-xl text-gray-600">
            Powerful tools and technologies to help your website perform at its best. We handle the technical details so you can focus on your content.
          </p>
        </div>
        
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-white rounded-xl p-8 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <div className="mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <a 
            href="#" 
            className="inline-flex items-center text-blue-600 hover:text-blue-800 font-medium transition-colors"
          >
            View all features
            <ArrowUpRight className="ml-2 h-4 w-4" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;