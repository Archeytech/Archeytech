import React, { useState, useEffect } from 'react';
import { Menu, X, ChevronDown, Globe } from 'lucide-react';
import Logo from './Logo';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Logo />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <div className="relative group">
              <button className="flex items-center text-gray-700 hover:text-blue-600 font-medium transition-colors">
                Hosting <ChevronDown className="ml-1 h-4 w-4" />
              </button>
              <div className="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg py-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Web Hosting</a>
                <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">WordPress Hosting</a>
                <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">VPS Hosting</a>
              </div>
            </div>
            <div className="relative group">
              <button className="flex items-center text-gray-700 hover:text-blue-600 font-medium transition-colors">
                Domains <ChevronDown className="ml-1 h-4 w-4" />
              </button>
              <div className="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg py-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Domain Registration</a>
                <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Domain Transfer</a>
                <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">WHOIS Lookup</a>
              </div>
            </div>
            <a href="#" className="text-gray-700 hover:text-blue-600 font-medium transition-colors">Website Builder</a>
            <a href="#" className="text-gray-700 hover:text-blue-600 font-medium transition-colors">Email</a>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Globe className="h-4 w-4 text-gray-500" />
              <span className="text-sm text-gray-700">EN</span>
            </div>
            <a href="#" className="text-gray-700 hover:text-blue-600 font-medium transition-colors">Login</a>
            <a 
              href="#" 
              className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-md font-medium transition-colors"
            >
              Get Started
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-gray-700" 
            onClick={toggleMenu}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div 
        className={`md:hidden bg-white absolute w-full top-full left-0 shadow-md transition-transform duration-300 transform ${
          isMenuOpen ? 'translate-y-0' : '-translate-y-full'
        }`}
      >
        <div className="px-4 py-3 space-y-3">
          <div className="border-b pb-2">
            <button className="flex items-center justify-between w-full text-gray-700 font-medium py-2">
              Hosting <ChevronDown className="h-4 w-4" />
            </button>
          </div>
          <div className="border-b pb-2">
            <button className="flex items-center justify-between w-full text-gray-700 font-medium py-2">
              Domains <ChevronDown className="h-4 w-4" />
            </button>
          </div>
          <a href="#" className="block text-gray-700 font-medium py-2">Website Builder</a>
          <a href="#" className="block text-gray-700 font-medium py-2">Email</a>
          <div className="pt-2 flex flex-col space-y-2">
            <a href="#" className="text-gray-700 font-medium py-2">Login</a>
            <a 
              href="#" 
              className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-md font-medium text-center transition-colors"
            >
              Get Started
            </a>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;