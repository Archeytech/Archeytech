import React from 'react';
import { CheckCircle, ChevronRight } from 'lucide-react';

const HeroSection: React.FC = () => {
  return (
    <section className="pt-24 pb-16 md:pt-32 md:pb-24 bg-gradient-to-br from-blue-50 to-indigo-50 overflow-hidden">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div>
              <span className="inline-block px-4 py-1.5 rounded-full bg-blue-100 text-blue-800 font-medium text-sm mb-4">
                Limited Time Offer: 75% OFF Web Hosting
              </span>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 leading-tight mb-4">
                Web Hosting Made <span className="text-blue-600">Easy & Affordable</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Everything you need to create and grow your website. From speed to support, we've got you covered.
              </p>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <CheckCircle className="h-5 w-5 text-green-500 shrink-0" />
                <span className="text-lg text-gray-700">Free Domain with annual plans</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="h-5 w-5 text-green-500 shrink-0" />
                <span className="text-lg text-gray-700">Free SSL Certificate ($11.95 value)</span>
              </div>
              <div className="flex items-center space-x-3">
                <CheckCircle className="h-5 w-5 text-green-500 shrink-0" />
                <span className="text-lg text-gray-700">24/7/365 Expert Support</span>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <a 
                href="#" 
                className="flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-md font-medium text-lg transition-colors"
              >
                Get Started
                <ChevronRight className="ml-2 h-5 w-5" />
              </a>
              <a 
                href="#" 
                className="flex items-center justify-center bg-white hover:bg-gray-100 text-gray-800 border border-gray-300 px-8 py-4 rounded-md font-medium text-lg transition-colors"
              >
                View Plans
              </a>
            </div>
            
            <div className="flex items-center space-x-2 text-sm text-gray-500">
              <span>Starting at just</span>
              <span className="text-xl font-bold text-blue-600">$1.99/mo</span>
              <span>with a 30-day money-back guarantee</span>
            </div>
          </div>
          
          <div className="relative">
            <div className="absolute -top-16 -right-16 w-64 h-64 bg-purple-200 rounded-full opacity-30 mix-blend-multiply filter blur-xl animate-blob"></div>
            <div className="absolute top-16 -right-8 w-64 h-64 bg-blue-200 rounded-full opacity-30 mix-blend-multiply filter blur-xl animate-blob animation-delay-2000"></div>
            <div className="absolute -top-8 -right-20 w-64 h-64 bg-indigo-200 rounded-full opacity-30 mix-blend-multiply filter blur-xl animate-blob animation-delay-4000"></div>
            
            <div className="relative bg-white p-6 rounded-2xl shadow-xl transform hover:scale-105 transition-transform duration-300">
              <img 
                src="https://images.pexels.com/photos/6177645/pexels-photo-6177645.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Website Dashboard" 
                className="rounded-lg w-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;