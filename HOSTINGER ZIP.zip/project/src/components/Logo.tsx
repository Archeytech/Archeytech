import React from 'react';
import { Server } from 'lucide-react';

const Logo: React.FC = () => {
  return (
    <div className="flex items-center">
      <Server className="h-8 w-8 text-blue-600" />
      <span className="ml-2 text-2xl font-bold text-gray-900">Hostify</span>
    </div>
  );
};

export default Logo;