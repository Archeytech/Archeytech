import React, { useState } from 'react';
import { Search, ChevronRight, Check } from 'lucide-react';

const DomainSection: React.FC = () => {
  const [domain, setDomain] = useState('');
  const [tld, setTld] = useState('.com');
  
  const tlds = [
    { name: '.com', price: 8.99 },
    { name: '.org', price: 9.99 },
    { name: '.net', price: 10.99 },
    { name: '.co', price: 12.99 },
    { name: '.io', price: 29.99 },
    { name: '.me', price: 14.99 },
  ];
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle domain search functionality here
    console.log('Searching for:', domain + tld);
  };

  return (
    <section className="py-16 md:py-24 bg-gradient-to-br from-indigo-50 to-blue-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Find Your Perfect Domain Name
          </h2>
          <p className="text-xl text-gray-600">
            Your online journey starts with the perfect domain. Check availability and secure your domain name today.
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto rounded-2xl bg-white shadow-lg overflow-hidden">
          <div className="p-6 md:p-8">
            <form onSubmit={handleSubmit} className="flex flex-col md:flex-row gap-4">
              <div className="flex-grow">
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <input
                    type="text"
                    placeholder="Find your domain name"
                    value={domain}
                    onChange={(e) => setDomain(e.target.value)}
                    className="w-full pl-12 pr-4 py-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors"
                    required
                  />
                </div>
              </div>
              
              <div className="w-full md:w-32">
                <select
                  value={tld}
                  onChange={(e) => setTld(e.target.value)}
                  className="w-full py-4 px-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors appearance-none bg-white"
                >
                  {tlds.map((item) => (
                    <option key={item.name} value={item.name}>
                      {item.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <button
                type="submit"
                className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-4 px-6 rounded-lg transition-colors flex items-center justify-center"
              >
                Search
                <ChevronRight className="ml-2 h-5 w-5" />
              </button>
            </form>
          </div>
          
          <div className="bg-gray-50 p-6 md:p-8 border-t border-gray-100">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {tlds.map((tld) => (
                <div key={tld.name} className="bg-white p-4 rounded-lg border border-gray-200 text-center">
                  <div className="font-bold text-gray-900">{tld.name}</div>
                  <div className="text-green-600 font-medium">${tld.price}/year</div>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="mt-16 grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Free with Every Domain</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mt-0.5 shrink-0" />
                <span className="ml-3 text-gray-700">Free WHOIS Privacy Protection</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mt-0.5 shrink-0" />
                <span className="ml-3 text-gray-700">DNS Management</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-green-500 mt-0.5 shrink-0" />
                <span className="ml-3 text-gray-700">Email Forwarding</span>
              </li>
            </ul>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Domain Transfer</h3>
            <p className="text-gray-600 mb-4">
              Already have a domain? Transfer it to us for better management and potential savings.
            </p>
            <a 
              href="#" 
              className="text-blue-600 hover:text-blue-800 font-medium flex items-center"
            >
              Transfer your domain
              <ChevronRight className="ml-1 h-5 w-5" />
            </a>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Domain Bulk Orders</h3>
            <p className="text-gray-600 mb-4">
              Need multiple domains? Get special pricing and simplified management for bulk orders.
            </p>
            <a 
              href="#" 
              className="text-blue-600 hover:text-blue-800 font-medium flex items-center"
            >
              Contact us for bulk pricing
              <ChevronRight className="ml-1 h-5 w-5" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DomainSection;