import React, { useState } from 'react';
import { CheckCircle, Info } from 'lucide-react';

type PlanPeriod = 'monthly' | 'yearly';

const PricingSection: React.FC = () => {
  const [period, setPeriod] = useState<PlanPeriod>('yearly');

  const plans = [
    {
      name: 'Single',
      tagline: 'Perfect for personal websites',
      monthlyPrice: 2.99,
      yearlyPrice: 1.99,
      features: [
        '1 Website',
        '50 GB SSD Storage',
        '~10,000 Visits Monthly',
        '1 Email Account',
        'Free SSL',
        'Free Domain (1 year)',
        '100 GB Bandwidth',
        '2 Databases',
      ],
      recommended: false,
      discount: 'Save 33%',
    },
    {
      name: 'Premium',
      tagline: 'Ideal for small businesses',
      monthlyPrice: 5.99,
      yearlyPrice: 3.99,
      features: [
        '100 Websites',
        '100 GB SSD Storage',
        '~25,000 Visits Monthly',
        'Free Email',
        'Free SSL',
        'Free Domain (1 year)',
        'Unlimited Bandwidth',
        'Unlimited Databases',
        'Free CDN',
        'Daily Backups',
      ],
      recommended: true,
      discount: 'Save 40%',
    },
    {
      name: 'Business',
      tagline: 'For high-traffic websites',
      monthlyPrice: 9.99,
      yearlyPrice: 6.99,
      features: [
        '100 Websites',
        '200 GB SSD Storage',
        '~100,000 Visits Monthly',
        'Free Email',
        'Free SSL',
        'Free Domain (1 year)',
        'Unlimited Bandwidth',
        'Unlimited Databases',
        'Free CDN',
        'Daily Backups',
        'Dedicated IP Address',
        'Priority Support',
      ],
      recommended: false,
      discount: 'Save 30%',
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-white" id="pricing">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Web Hosting That Fits Your Needs
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Choose the perfect hosting solution for your website with our flexible plans. All plans include a free domain, SSL certificate, and 24/7 support.
          </p>
          
          <div className="flex items-center justify-center mb-8">
            <div className="bg-gray-100 p-1 rounded-full flex items-center">
              <button
                className={`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
                  period === 'monthly' ? 'bg-white shadow-sm text-gray-900' : 'bg-transparent text-gray-600'
                }`}
                onClick={() => setPeriod('monthly')}
              >
                Monthly
              </button>
              <button
                className={`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
                  period === 'yearly' ? 'bg-white shadow-sm text-gray-900' : 'bg-transparent text-gray-600'
                }`}
                onClick={() => setPeriod('yearly')}
              >
                Yearly
              </button>
            </div>
          </div>
          
          {period === 'yearly' && (
            <div className="bg-blue-50 text-blue-700 px-4 py-2 rounded-full inline-flex items-center">
              <span className="text-sm font-medium">
                Save up to 40% with yearly plans
              </span>
            </div>
          )}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan) => (
            <div 
              key={plan.name} 
              className={`bg-white rounded-2xl shadow-lg transition-transform duration-300 hover:shadow-xl p-8 border ${
                plan.recommended ? 'border-blue-500 relative transform md:scale-105' : 'border-gray-100'
              }`}
            >
              {plan.recommended && (
                <div className="absolute top-0 inset-x-0 transform -translate-y-1/2">
                  <span className="bg-blue-600 text-white text-sm font-medium px-4 py-1 rounded-full inline-block">
                    Most Popular
                  </span>
                </div>
              )}
              
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                <p className="text-gray-600">{plan.tagline}</p>
              </div>
              
              <div className="mb-6">
                <div className="flex items-end mb-2">
                  <span className="text-4xl font-bold text-gray-900">
                    ${period === 'monthly' ? plan.monthlyPrice : plan.yearlyPrice}
                  </span>
                  <span className="text-gray-600 ml-2">/mo</span>
                </div>
                <div className="flex items-center">
                  {period === 'yearly' && (
                    <span className="text-sm bg-green-100 text-green-800 px-2 py-0.5 rounded-full font-medium">
                      {plan.discount}
                    </span>
                  )}
                  <span className="text-sm text-gray-500 ml-2">
                    {period === 'yearly' ? 'billed yearly' : 'billed monthly'}
                  </span>
                </div>
              </div>
              
              <a 
                href="#" 
                className={`block text-center rounded-lg font-medium py-3 px-4 mb-8 transition-colors ${
                  plan.recommended 
                    ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                    : 'bg-gray-100 hover:bg-gray-200 text-gray-900'
                }`}
              >
                Select Plan
              </a>
              
              <div className="space-y-3">
                {plan.features.map((feature, i) => (
                  <div key={i} className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 shrink-0" />
                    <span className="ml-3 text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <div className="inline-flex items-center text-gray-600 bg-gray-50 px-4 py-2 rounded-lg">
            <Info className="h-5 w-5 mr-2 text-blue-500" />
            <span>All plans come with a 30-day money-back guarantee</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PricingSection;